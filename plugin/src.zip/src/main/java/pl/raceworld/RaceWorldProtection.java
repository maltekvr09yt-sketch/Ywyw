package pl.raceworld;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class RaceWorldProtection extends JavaPlugin implements Listener {

    private static final String WORLD = "hub2";

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("RaceWorldProtection wlaczony dla swiata hub2.");
    }

    @EventHandler
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player player
                && player.getWorld().getName().equalsIgnoreCase(WORLD)) {
            event.setCancelled(true);
            player.setFoodLevel(20);
            player.setSaturation(20.0f);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player
                && player.getWorld().getName().equalsIgnoreCase(WORLD)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();

        if (player.getWorld().getName().equalsIgnoreCase(WORLD)) {
            Bukkit.getScheduler().runTask(this, () -> teleportToSpawn(player));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        if (player.getWorld().getName().equalsIgnoreCase(WORLD)) {
            Bukkit.getScheduler().runTask(this, () -> teleportToSpawn(player));
        }
    }

    private void teleportToSpawn(Player player) {
        World world = Bukkit.getWorld(WORLD);

        if (world == null) {
            getLogger().warning("Nie znaleziono swiata '" + WORLD + "'.");
            return;
        }

        Location location = new Location(world, 0.5, 66.0, -20.5, 0.0f, 0.0f);
        player.teleport(location);
    }
}
