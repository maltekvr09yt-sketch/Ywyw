# RaceWorldProtection

Plugin pod Paper 1.21.4 / Java 21.

Funkcje w świecie `race`:
- brak spadku głodu,
- brak obrażeń gracza,
- brak fall damage (jest częścią blokady obrażeń),
- po wejściu do świata `race` teleport do świata `hub2` na X=0.5, Y=66, Z=-20.5, yaw=0, pitch=0.

Wymagania:
- Paper 1.21.4
- Java 21
- świat `hub2` musi istnieć i być załadowany.
